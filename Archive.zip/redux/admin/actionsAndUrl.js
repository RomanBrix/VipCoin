export const GLOB_URL = "https://vipcoin.technology/admin/";

export const act = {
    REQUEST: "REQUEST",
    GET_GEN_INFO: "GET_GENERALLY_INFO",
    SET_GEN_INFO: "SET_GENERALLY_INFO",
    GET_USERS_INFO: "GET_USERS_INFO",
    GET_PACKAGES_INFO: "GET_PACKAGES_INFO",

};