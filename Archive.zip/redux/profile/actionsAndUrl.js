export const GLOB_URL = "https://vipcoin.technology/profile/";

export const act = {
    GET_HASH: "GET_HASH",
    PACKAGES: "GET_PACKAGES",
    USER: "GET_USER_INFO",
    GET_CRYPTO: "GET_CRYPTO",
    UPDATED: "SETTINGS_UPDATING",
    COINCOST: "ONECOINCOST"
};