<?php
 /*
  *
 $host = 'localhost'; // адрес сервера
 $database = 'vipcoin_db'; // имя базы данных
 $user = 'root'; // имя пользователя
 $password = 'root'; // пароль
*/
$database= 'u0394512_coins_f';
$user = 'u0394512_coins';
$password= '3S7d4R9q';
$host = 'localhost';
 ?>