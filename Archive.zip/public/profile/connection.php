<?php
 $host = 'localhost'; // адрес сервера
 $database = 'u0394512_coins_f'; // имя базы данных
 $user = 'u0394512_coins'; // имя пользователя
 $password = '3S7d4R9q'; // пароль

/*
 *
$database= 'u0394512_coins_f';
$user = 'u0394512_coins';
$password= '3S7d4R9q';
$host = 'localhost';
 */
?>